package com.pdsa.toolusage;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.pdsa.toolusage.boarding.BoardingManager;
import com.pdsa.toolusage.model.Passenger;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class BoardingActivity extends AppCompatActivity {

    private BoardingManager boardingManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boarding);

        EditText etName = findViewById(R.id.etName);
        EditText etId = findViewById(R.id.etId);
        RadioGroup rgClass = findViewById(R.id.rgClass);
        RadioGroup rgAssistance = findViewById(R.id.rgAssistance);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvBoarding = findViewById(R.id.tvBoarding);

        // Initialize BoardingManager with duration and capacity
        boardingManager = new BoardingManager(2.0, 100);

        btnRegister.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String id = etId.getText().toString().trim();

            String cls = (rgClass.getCheckedRadioButtonId() == R.id.rbBusiness)
                    ? "BUSINESS" : "ECONOMY";

            boolean assistance = (rgAssistance.getCheckedRadioButtonId() == R.id.rbYes);

            if (name.isEmpty() || id.isEmpty()) {
                tvBoarding.setText("❌ Fill all fields");
                return;
            }

            // Register passenger in BoardingManager (priority queue handles ordering)
            boardingManager.registerPassenger(name, id, cls, LocalDateTime.now(), assistance);

            // Display the boarding queue
            updateBoardingQueue(tvBoarding);

            // Clear input fields
            etName.setText("");
            etId.setText("");
            rgClass.check(R.id.rbEconomy);
            rgAssistance.check(R.id.rbNo);
        });
    }

    // Helper to refresh the boarding queue display
    private void updateBoardingQueue(TextView tvBoarding) {
        List<Passenger> list = boardingManager.getPassengers();

        if (list.isEmpty()) {
            tvBoarding.setText("No passengers in queue");
            return;
        }

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm:ss");
        StringBuilder sb = new StringBuilder("Current Boarding Queue\n\n");

        int i = 1;
        for (Passenger p : list) {
            sb.append(i++).append(". ")
                    .append(p.getName())
                    .append(" (").append(p.getTravelClass()).append(")")
                    .append(p.isAssistance() ? " 🚩" : "")
                    .append(" | Check-in - ").append(fmt.format(p.getCheckIn()))
                    .append("\n");
        }

        tvBoarding.setText(sb.toString());
    }
}
