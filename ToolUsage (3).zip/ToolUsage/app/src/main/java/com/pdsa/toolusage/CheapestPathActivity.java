package com.pdsa.toolusage;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.pdsa.toolusage.graph.Graph;
import com.pdsa.toolusage.model.Airport;
import com.pdsa.toolusage.model.Edge;

import java.util.Arrays;
import java.util.List;

public class CheapestPathActivity extends AppCompatActivity {

    private Graph graph;
    private List<Airport> airports;
    private CheapestGraphView graphView; // ① Declare graph view

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheapest_path);

        TextView tvAirportList = findViewById(R.id.tvAirportList);
        EditText etSource = findViewById(R.id.etSource);
        EditText etDestination = findViewById(R.id.etDestination);
        Button btnFind = findViewById(R.id.btnFindPath);
        TextView tvResult = findViewById(R.id.tvResult);

        graphView = findViewById(R.id.graphView); // ② Initialize graph view

        initGraph();

        // Display available airports
        StringBuilder sb = new StringBuilder();
        for (Airport a : airports) sb.append(a.getCode()).append(" - ").append(a.getName()).append("\n");
        tvAirportList.setText(sb.toString());

        // Set graph to the view
        graphView.setGraph(graph, airports);

        btnFind.setOnClickListener(v -> {
            String srcCode = etSource.getText().toString().trim().toUpperCase();
            String dstCode = etDestination.getText().toString().trim().toUpperCase();

            Airport src = airports.stream().filter(a -> a.getCode().equals(srcCode)).findFirst().orElse(null);
            Airport dst = airports.stream().filter(a -> a.getCode().equals(dstCode)).findFirst().orElse(null);

            if (src == null || dst == null) {
                tvResult.setText("❌ Invalid airport code!");
                return;
            }

            Graph.DijkstraResult result = graph.dijkstra(src, dst, Edge::getCost);

            if (result.total == Double.POSITIVE_INFINITY) {
                tvResult.setText("❌ No flights available for this route!");
                return;
            }

            // Highlight cheapest path in GraphView
            graphView.setCheapestPath(result.path);

            StringBuilder pathStr = new StringBuilder();
            for (Airport a : result.path) pathStr.append(a.getCode()).append(" -> ");
            if (!result.path.isEmpty()) pathStr.setLength(pathStr.length() - 4);

            tvResult.setText("Cheapest Path (Cost)\n" + pathStr + "\nTotal cost = $" + result.total);
        });

    }

    private void initGraph() {
        graph = new Graph();
        Airport CMB = new Airport("CMB", "Colombo");
        Airport BLR = new Airport("BLR", "Bengaluru");
        Airport DEL = new Airport("DEL", "Delhi");
        Airport DXB = new Airport("DXB", "Dubai");
        Airport LHR = new Airport("LHR", "London Heathrow");
        Airport JFK = new Airport("JFK", "New York");
        Airport SIN = new Airport("SIN", "Singapore");
        Airport SYD = new Airport("SYD", "Sydney");
        Airport HND = new Airport("HND", "Tokyo Haneda");
        Airport CDG = new Airport("CDG", "Paris Charles de Gaulle");

        airports = Arrays.asList(CMB, BLR, DEL, DXB, LHR, JFK, SIN, SYD, HND, CDG);

        // Updated to match Graph.addRoute signature
        graph.addRoute(CMB, BLR, 700, 120, 1.5, 180);
        graph.addRoute(CMB, DEL, 2400, 280, 3.0, 200);
        graph.addRoute(CMB, DXB, 3300, 400, 4.5, 220);
        graph.addRoute(BLR, DEL, 1700, 200, 2.5, 150);
        graph.addRoute(BLR, SIN, 3200, 350, 4.0, 200);
        graph.addRoute(DEL, LHR, 6700, 700, 9.0, 300);
        graph.addRoute(DXB, LHR, 5500, 600, 8.0, 280);
        graph.addRoute(DXB, JFK, 11000, 900, 14.0, 320);
        graph.addRoute(SIN, SYD, 6200, 750, 8.5, 260);
        graph.addRoute(SIN, HND, 5300, 600, 7.5, 240);
        graph.addRoute(LHR, JFK, 5600, 650, 8.5, 300);
        graph.addRoute(LHR, CDG, 350, 100, 1.0, 180);
        graph.addRoute(HND, SYD, 7800, 850, 10.0, 280);
    }
}
