package com.pdsa.toolusage;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import com.pdsa.toolusage.graph.Graph;
import com.pdsa.toolusage.model.Airport;
import com.pdsa.toolusage.model.Edge;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GraphView extends View {
    private Paint nodePaint, textPaint, edgePaint, pathPaint, labelPaint, arrowPaint;
    private Map<String, float[]> positions = new HashMap<>();
    private List<Airport> airports;
    private List<Airport> shortestPath;
    private Graph graph;
    private float verticalScale = 2.5f;
    private float horizontalScale = 1.5f;
    private float scaleFactor = 0.9f; // Scale factor to fit within screen

    public GraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        nodePaint = new Paint();
        nodePaint.setColor(Color.parseColor("#2196F3"));
        nodePaint.setStyle(Paint.Style.FILL);
        nodePaint.setAntiAlias(true);

        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(32f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setAntiAlias(true);

        labelPaint = new Paint();
        labelPaint.setColor(Color.BLACK);
        labelPaint.setTextSize(24f);
        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setAntiAlias(true);

        edgePaint = new Paint();
        edgePaint.setColor(Color.parseColor("#9E9E9E")); // Darker gray for better visibility
        edgePaint.setStrokeWidth(3f);
        edgePaint.setAntiAlias(true);

        pathPaint = new Paint();
        pathPaint.setColor(Color.parseColor("#FF5252")); // Brighter red
        pathPaint.setStrokeWidth(6f);
        pathPaint.setAntiAlias(true);

        arrowPaint = new Paint();
        arrowPaint.setColor(Color.parseColor("#9E9E9E"));
        arrowPaint.setStyle(Paint.Style.FILL);
        arrowPaint.setAntiAlias(true);
    }

    public void setGraph(Graph graph, List<Airport> airports) {
        this.graph = graph;
        this.airports = airports;
        invalidate();
    }

    public void setShortestPath(List<Airport> path) {
        this.shortestPath = path;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (airports == null || airports.isEmpty()) return;

        int width = getWidth();
        int height = getHeight();
        int padding = 150; // Increased padding
        int n = airports.size();

        // Arrange airports in a circle with proper scaling
        float centerX = width / 2f;
        float centerY = height / 2f;
        float radius = Math.min(width, height) * scaleFactor / 2f - padding;

        positions.clear();
        for (int i = 0; i < n; i++) {
            double angle = 2 * Math.PI * i / n;
            float x = (float) (centerX + radius * horizontalScale * Math.cos(angle));
            float y = (float) (centerY + radius * verticalScale * Math.sin(angle));
            positions.put(airports.get(i).getCode(), new float[]{x, y});
        }

        // Draw all edges (routes) first
        if (graph != null) {
            for (Airport a : airports) {
                for (Edge edge : graph.neighbors(a)) {
                    Airport b = edge.getTo();
                    float[] p1 = positions.get(a.getCode());
                    float[] p2 = positions.get(b.getCode());

                    if (p1 != null && p2 != null) {
                        // Calculate direction vector
                        float dx = p2[0] - p1[0];
                        float dy = p2[1] - p1[1];
                        float distance = (float) Math.sqrt(dx * dx + dy * dy);

                        // Normalize
                        dx /= distance;
                        dy /= distance;

                        // Adjust start and end points to avoid overlapping with nodes
                        float startX = p1[0] + dx * 50;
                        float startY = p1[1] + dy * 50;
                        float endX = p2[0] - dx * 50;
                        float endY = p2[1] - dy * 50;

                        // Draw the edge line
                        canvas.drawLine(startX, startY, endX, endY, edgePaint);

                        // Draw arrow head
                        drawArrow(canvas, endX, endY, dx, dy, edgePaint);

                        // Draw distance label at midpoint with offset
                        float midX = (startX + endX) / 2 - dy * 20;
                        float midY = (startY + endY) / 2 + dx * 20;

                        // Draw background for better text visibility
                        Paint bgPaint = new Paint();
                        bgPaint.setColor(Color.WHITE);
                        bgPaint.setStyle(Paint.Style.FILL);
                        String text = (int) edge.getDistance() + " km";
                        float textWidth = labelPaint.measureText(text);
                        canvas.drawRect(midX - textWidth/2 - 5, midY - 15,
                                midX + textWidth/2 + 5, midY + 5, bgPaint);

                        canvas.drawText(text, midX, midY, labelPaint);
                    }
                }
            }
        }

        // Highlight shortest path with thicker lines and different color
        if (shortestPath != null && shortestPath.size() > 1) {
            for (int i = 0; i < shortestPath.size() - 1; i++) {
                Airport a = shortestPath.get(i);
                Airport b = shortestPath.get(i + 1);
                float[] p1 = positions.get(a.getCode());
                float[] p2 = positions.get(b.getCode());

                if (p1 != null && p2 != null) {
                    // Calculate direction vector
                    float dx = p2[0] - p1[0];
                    float dy = p2[1] - p1[1];
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);

                    // Normalize
                    dx /= distance;
                    dy /= distance;

                    // Adjust start and end points
                    float startX = p1[0] + dx * 50;
                    float startY = p1[1] + dy * 50;
                    float endX = p2[0] - dx * 50;
                    float endY = p2[1] - dy * 50;

                    // Draw the path line
                    canvas.drawLine(startX, startY, endX, endY, pathPaint);

                    // Draw arrow head for path
                    drawArrow(canvas, endX, endY, dx, dy, pathPaint);
                }
            }
        }

        // Draw nodes on top of everything
        for (Airport a : airports) {
            float[] pos = positions.get(a.getCode());
            if (pos != null) {
                // Draw node
                canvas.drawCircle(pos[0], pos[1], 50, nodePaint);

                // Draw airport code
                canvas.drawText(a.getCode(), pos[0], pos[1] + 12, textPaint);
            }
        }
    }

    private void drawArrow(Canvas canvas, float x, float y, float dx, float dy, Paint paint) {
        float arrowSize = 20f;

        // Calculate perpendicular vector
        float perpX = -dy;
        float perpY = dx;

        // Create arrow path
        Path arrowPath = new Path();
        arrowPath.moveTo(x, y);
        arrowPath.lineTo(x - dx * arrowSize + perpX * arrowSize/2,
                y - dy * arrowSize + perpY * arrowSize/2);
        arrowPath.lineTo(x - dx * arrowSize - perpX * arrowSize/2,
                y - dy * arrowSize - perpY * arrowSize/2);
        arrowPath.close();

        // Draw arrow
        canvas.drawPath(arrowPath, paint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // Ensure the view has a reasonable minimum size
        int minDimension = 600; // Minimum dimension in pixels
        int width = Math.max(MeasureSpec.getSize(widthMeasureSpec), minDimension);
        int height = Math.max(MeasureSpec.getSize(heightMeasureSpec), minDimension);

        setMeasuredDimension(width, height);
    }
}