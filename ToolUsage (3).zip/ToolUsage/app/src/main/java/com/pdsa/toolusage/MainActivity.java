package com.pdsa.toolusage;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

public class MainActivity extends AppCompatActivity {

    private MaterialCardView cardShortest, cardCheapest, cardCheckin, cardAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardShortest = findViewById(R.id.cardShortest);
        cardCheapest = findViewById(R.id.cardCheapest);
        cardCheckin = findViewById(R.id.cardCheckin);
        cardAbout = findViewById(R.id.cardAbout);

        cardShortest.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ShortestPathActivity.class));
        });

        cardCheapest.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, CheapestPathActivity.class));
        });

        cardCheckin.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, BoardingActivity.class));
        });

        cardAbout.setOnClickListener(v -> {
            // Simple exit
            finish();
        });
    }
}
