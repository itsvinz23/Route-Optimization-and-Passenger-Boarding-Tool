package com.pdsa.toolusage.boarding;

import com.pdsa.toolusage.model.Passenger;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class BoardingManager {

    private final PriorityQueue<Passenger> pq;
    private long seqCounter = 0;

    private double duration; // hours
    private int capacity;    // seats

    public BoardingManager(double duration, int capacity) {
        this.duration = duration;
        this.capacity = capacity;

        // Max-heap: higher rank = higher priority
        pq = new PriorityQueue<>(
                Comparator.comparingInt(this::getRank).reversed() // invert for max-heap
                        .thenComparingLong(Passenger::getArrivalSeq) // FIFO if same rank
        );
    }

    public Passenger registerPassenger(String name, String id, String travelClass,
                                       LocalDateTime checkIn, boolean assistance) {
        if (pq.size() >= capacity) {
            System.out.println("❌ Flight full! Cannot add more passengers.");
            return null;
        }
        Passenger p = new Passenger(name, id, travelClass, checkIn, assistance, ++seqCounter);
        pq.add(p);
        return p;
    }

    public Passenger nextToBoard() {
        return pq.poll(); // highest priority dequeued first
    }

    public boolean hasPassengers() {
        return !pq.isEmpty();
    }

    /** Return passengers sorted by priority for display/UI */
    public List<Passenger> getPassengers() {
        List<Passenger> list = new ArrayList<>(pq);
        list.sort(
                Comparator.comparingInt(this::getRank).reversed()
                        .thenComparingLong(Passenger::getArrivalSeq)
        );
        return list;
    }

    /** Optional: console display */
    public void displayBoardingQueue() {
        System.out.printf("\n=== Boarding Queue (Duration: %.1f hrs | Capacity: %d seats) ===%n",
                duration, capacity);

        List<Passenger> list = getPassengers(); // always sorted
        if (list.isEmpty()) {
            System.out.println("No passengers waiting.");
            return;
        }

        System.out.printf("%-5s %-15s %-15s %-12s %-10s%n", "No.", "Name", "ID", "Class", "Assist");
        System.out.println("---------------------------------------------------------");
        int i = 1;
        for (Passenger p : list) {
            System.out.printf("%-5d %-15s %-15s %-12s %-10s%n",
                    i++, p.getName(), p.getId(), p.getTravelClass(),
                    p.isAssistance() ? "🚩" : "");
        }
    }

    /** Helper: rank by class + assistance */
    private int getRank(Passenger p) {
        if (p.getTravelClass().equalsIgnoreCase("BUSINESS") && p.isAssistance()) return 4;
        if (p.getTravelClass().equalsIgnoreCase("BUSINESS")) return 3;
        if (p.getTravelClass().equalsIgnoreCase("ECONOMY") && p.isAssistance()) return 2;
        return 1; // ECONOMY no assistance
    }
}
